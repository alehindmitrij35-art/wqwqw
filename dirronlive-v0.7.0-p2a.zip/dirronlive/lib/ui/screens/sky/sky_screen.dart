import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../features/minecraft/link_protocol.dart';
import '../../../features/minecraft/minecraft_link.dart';
import '../../../features/modes/modes_catalog.dart';
import '../../../features/sky/sky_catalog.dart';
import '../../../features/sky/sky_engine.dart';
import '../../../features/sky/sky_settings.dart';
import '../../theme/app_colors.dart';
import '../../widgets/common.dart';
import '../parkour/action_look.dart';
import '../parkour/gift_catalog_dialog.dart';

/// Цвета режима (по заданию): фон, карточки, акцент, дополнительный, текст.
abstract final class SkyColors {
  static const background = Color(0xFF11101C);
  static const card = Color(0xFF211D33);
  static const accent = Color(0xFFA78BFA);
  static const extra = Color(0xFFE879F9);
  static const text = Color(0xFFF5F3FF);
  static const border = Color(0xFF342C52);

  static Color tier(SkyTier t) => switch (t) {
        SkyTier.cheap => const Color(0xFF5EEAD4),
        SkyTier.medium => accent,
        SkyTier.expensive => const Color(0xFFFDE68A),
      };
}

IconData skyIcon(String id) => switch (id) {
      'crosswind' => Icons.air_rounded,
      'heavy_wings' => Icons.fitness_center_rounded,
      'tailwind' => Icons.keyboard_double_arrow_right_rounded,
      'turbulence' => Icons.waves_rounded,
      'narrow' => Icons.compress_rounded,
      'air_brake' => Icons.front_hand_rounded,
      'storm' => Icons.thunderstorm_rounded,
      'time_rift' => Icons.history_rounded,
      'slalom' => Icons.alt_route_rounded,
      'guardian' => Icons.shield_rounded,
      _ => Icons.auto_awesome_rounded,
    };

/// Режимы → «Небесный разлом»: состояние, управление заездом, 10 карточек
/// действий, профиль эффектов и журнал ответов мода.
class SkyScreen extends ConsumerWidget {
  const SkyScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(skySettingsProvider);
    // Создаёт движок (подписки на подарки), если его ещё нет.
    ref.watch(skyEngineProvider);
    return Container(
      color: SkyColors.background,
      child: SingleChildScrollView(
        key: const Key('sky-scroll'),
        padding: const EdgeInsets.fromLTRB(32, 20, 32, 32),
        child: Align(
          alignment: Alignment.topLeft,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1280),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton.icon(
                    key: const Key('sky-back'),
                    onPressed: () => ref.read(openModeProvider.notifier).open(null),
                    icon: const Icon(Icons.arrow_back_rounded, size: 18),
                    label: const Text('Режимы'),
                  ),
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 16,
                  runSpacing: 12,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    const PageHeader(
                      title: 'Небесный разлом',
                      subtitle: 'Полёт на элитрах через кольца: 6 секторов, зрители мешают и помогают подарками',
                    ),
                    _ModeSwitch(active: settings.modeActive),
                  ],
                ),
                const SizedBox(height: 18),
                const _StatusCard(),
                const SizedBox(height: 14),
                const _Controls(),
                const SizedBox(height: 14),
                _ProfileCard(settings: settings),
                const SizedBox(height: 22),
                for (final tier in SkyTier.values) ...[
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10, top: 4),
                    child: Row(
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(color: SkyColors.tier(tier), shape: BoxShape.circle),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '${tier.title} · ${skyActions.where((a) => a.tier == tier).length}',
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: SkyColors.text),
                        ),
                      ],
                    ),
                  ),
                  LayoutBuilder(builder: (context, constraints) {
                    const spacing = 14.0;
                    final columns = (constraints.maxWidth / 380).floor().clamp(1, 4).toInt();
                    final width = ((constraints.maxWidth - spacing * (columns - 1)) / columns).floorToDouble();
                    return Wrap(
                      spacing: spacing,
                      runSpacing: spacing,
                      children: [
                        for (final a in skyActions.where((x) => x.tier == tier))
                          SizedBox(width: width, child: _ActionCard(card: settings.card(a.id))),
                      ],
                    );
                  }),
                  const SizedBox(height: 18),
                ],
                const _JournalCard(),
                const SizedBox(height: 14),
                const _AboutCard(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SkyPanel extends StatelessWidget {
  const _SkyPanel({super.key, required this.child, this.borderColor});

  final Widget child;
  final Color? borderColor;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: SkyColors.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderColor ?? SkyColors.border),
        ),
        child: child,
      );
}

class _ModeSwitch extends ConsumerWidget {
  const _ModeSwitch({required this.active});

  final bool active;

  @override
  Widget build(BuildContext context, WidgetRef ref) => _SkyPanel(
        borderColor: active ? AppColors.success.withAlpha(120) : null,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              active ? 'Режим активен' : 'Режим выключен',
              style: TextStyle(fontWeight: FontWeight.w700, color: active ? AppColors.success : AppColors.textMuted),
            ),
            const SizedBox(width: 10),
            Switch(
              key: const Key('sky-mode-switch'),
              value: active,
              onChanged: (v) => ref.read(skySettingsProvider.notifier).setModeActive(v),
            ),
          ],
        ),
      );
}

// ------------------------------------------------------------- состояние

class _StatusCard extends ConsumerStatefulWidget {
  const _StatusCard();

  @override
  ConsumerState<_StatusCard> createState() => _StatusCardState();
}

class _StatusCardState extends ConsumerState<_StatusCard> {
  Timer? _tick;

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  /// Время на экране идёт само, пока игрок в полёте.
  void _ensureTicker(bool running) {
    if (running && _tick == null) {
      _tick = Timer.periodic(const Duration(milliseconds: 200), (_) {
        if (mounted) setState(() {});
      });
    } else if (!running && _tick != null) {
      _tick!.cancel();
      _tick = null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final link = ref.watch(minecraftLinkProvider);
    final sky = link.sky;
    final blocker = link.skyBlocker;
    _ensureTicker(blocker == null && sky.running);
    final mapColor = switch (sky.map) {
      'ready' => AppColors.success,
      'preparing' => AppColors.warning,
      _ => AppColors.textFaint,
    };
    return _SkyPanel(
      key: const Key('sky-status'),
      borderColor: blocker == null ? AppColors.success.withAlpha(110) : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 10,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              StatusPill.link(link),
              TagChip(label: 'Карта: ${skyMapLabel(sky.map)}', color: mapColor),
              TagChip(
                  label: sky.training ? 'Тренировка · ${skyPhaseLabel(sky.phase)}' : skyPhaseLabel(sky.phase),
                  color: sky.running ? AppColors.success : SkyColors.accent),
              if (sky.protection) const TagChip(label: 'Защита 3 с', color: AppColors.warning),
            ],
          ),
          if (blocker != null) ...[
            const SizedBox(height: 10),
            Text(blocker, key: const Key('sky-blocker'), style: const TextStyle(fontSize: 14, color: AppColors.warning)),
          ],
          const SizedBox(height: 14),
          Wrap(
            spacing: 28,
            runSpacing: 12,
            children: [
              _Big('Сектор', sky.sectors > 0 ? '${sky.sector < 1 ? 1 : sky.sector} / ${sky.sectors}' : '—',
                  key: const Key('sky-sector')),
              _Big('Кольцо', sky.rings > 0 ? '${sky.ring} / ${sky.rings}' : '—', key: const Key('sky-ring')),
              _Big('Время', skyClock(sky.msAt(DateTime.now())), key: const Key('sky-time')),
              _Big('Ошибки', '${sky.errors}',
                  note: sky.errors > 0 ? 'промахов ${sky.misses} · столкновений ${sky.crashes}' : null,
                  color: sky.errors == 0 ? AppColors.success : AppColors.danger,
                  key: const Key('sky-errors')),
              _Big('Рекорд', sky.bestMs > 0 ? skyClock(sky.bestMs) : '—'),
              _Big('Очередь', '${sky.queued}'),
            ],
          ),
          if (sky.countdown > 0) ...[
            const SizedBox(height: 8),
            Text('Старт через ${sky.countdown}…',
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: SkyColors.extra)),
          ],
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              if (sky.effects.isEmpty)
                const Text('Активных эффектов нет', style: TextStyle(fontSize: 13, color: AppColors.textFaint)),
              for (final e in sky.effects) _EffectChip(effect: e),
            ],
          ),
        ],
      ),
    );
  }
}

class _Big extends StatelessWidget {
  const _Big(this.label, this.value, {super.key, this.note, this.color});

  final String label;
  final String value;
  final String? note;
  final Color? color;

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textFaint)),
          Text(value,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w900,
                color: color ?? SkyColors.text,
                fontFeatures: const [FontFeature.tabularFigures()],
              )),
          if (note != null) Text(note!, style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
        ],
      );
}

class _EffectChip extends StatelessWidget {
  const _EffectChip({required this.effect});

  final SkyEffectInfo effect;

  @override
  Widget build(BuildContext context) {
    final a = skyActionById(effect.id);
    final color = a == null ? SkyColors.accent : SkyColors.tier(a.tier);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        color: color.withAlpha(30),
        border: Border.all(color: color.withAlpha(140)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(skyIcon(effect.id), size: 16, color: color),
          const SizedBox(width: 6),
          Text(
            '${a?.title ?? effect.id} · ${effect.seconds} с${effect.viewer.isEmpty ? '' : ' · ${effect.viewer}'}',
            style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: color),
          ),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------ управление

class _Controls extends ConsumerStatefulWidget {
  const _Controls();

  @override
  ConsumerState<_Controls> createState() => _ControlsState();
}

class _ControlsState extends ConsumerState<_Controls> {
  bool _busy = false;
  (bool, String)? _result;

  Future<void> _run(String cmd) async {
    setState(() => _busy = true);
    final r = await ref.read(skyEngineProvider).command(cmd);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _result = r;
    });
  }

  @override
  Widget build(BuildContext context) {
    final link = ref.watch(minecraftLinkProvider);
    final sky = link.sky;
    final ready = link.skyBlocker == null && !_busy;
    Widget btn(String cmd, String label, IconData icon, {bool primary = false, bool enabled = true}) {
      final onPressed = ready && enabled ? () => _run(cmd) : null;
      return primary
          ? FilledButton.icon(
              key: Key('sky-cmd-$cmd'), onPressed: onPressed, icon: Icon(icon, size: 18), label: Text(label))
          : OutlinedButton.icon(
              key: Key('sky-cmd-$cmd'), onPressed: onPressed, icon: Icon(icon, size: 18), label: Text(label));
    }

    return _SkyPanel(
      key: const Key('sky-controls'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              btn('start', sky.active ? 'Заново' : 'Старт', Icons.flight_takeoff_rounded, primary: true),
              if (sky.paused)
                btn('resume', 'Продолжить', Icons.play_arrow_rounded)
              else
                btn('pause', 'Пауза', Icons.pause_rounded, enabled: sky.phase == 'running' || sky.phase == 'countdown'),
              btn('restart', 'Быстрый рестарт', Icons.restart_alt_rounded, enabled: sky.active || sky.phase == 'finished'),
              btn('checkpoint', 'К контрольной точке', Icons.flag_rounded, enabled: sky.running),
              btn('stop', 'Закончить', Icons.stop_rounded, enabled: sky.active || sky.phase == 'finished'),
              btn('training', 'Тренировка', Icons.school_rounded),
            ],
          ),
          if (_result != null) ...[
            const SizedBox(height: 10),
            Text(
              _result!.$2,
              key: const Key('sky-cmd-result'),
              style: TextStyle(fontSize: 13, color: _result!.$1 ? AppColors.success : AppColors.danger),
            ),
          ],
        ],
      ),
    );
  }
}

class _ProfileCard extends ConsumerWidget {
  const _ProfileCard({required this.settings});

  final SkySettings settings;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = ref.read(skySettingsProvider.notifier);
    return _SkyPanel(
      key: const Key('sky-profile'),
      child: Wrap(
        spacing: 24,
        runSpacing: 14,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Профиль эффектов', style: TextStyle(fontSize: 12, color: AppColors.textFaint)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                children: [
                  for (final p in skyProfiles.entries)
                    ChoiceChip(
                      key: Key('sky-profile-${p.key}'),
                      label: Text('${p.value} · ${skyProfileParticles[p.key]} частиц'),
                      selected: settings.profile == p.key,
                      onSelected: (_) => c.setProfile(p.key),
                    ),
                ],
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Клавиша быстрого рестарта', style: TextStyle(fontSize: 12, color: AppColors.textFaint)),
              DropdownButton<String>(
                key: const Key('sky-restart-key'),
                value: settings.restartKey,
                dropdownColor: SkyColors.card,
                items: [
                  for (final k in skyRestartKeys) DropdownMenuItem(value: k, child: Text(skyKeyLabel(k))),
                ],
                onChanged: (v) {
                  if (v != null) c.setRestartKey(v);
                },
              ),
            ],
          ),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('Меньше вспышек', style: TextStyle(fontSize: 14, color: SkyColors.text)),
              const SizedBox(width: 6),
              Switch(
                key: const Key('sky-reduce-flashes'),
                value: settings.reduceFlashes,
                onChanged: c.setReduceFlashes,
              ),
            ],
          ),
          const Text(
            'Низкий FPS — мод сам уменьшает только украшения (частицы), кольца остаются.',
            style: TextStyle(fontSize: 12, color: AppColors.textMuted),
          ),
        ],
      ),
    );
  }
}

// --------------------------------------------------------------- карточки

class _ActionCard extends ConsumerStatefulWidget {
  const _ActionCard({required this.card});

  final SkyCard card;

  @override
  ConsumerState<_ActionCard> createState() => _ActionCardState();
}

class _ActionCardState extends ConsumerState<_ActionCard> {
  bool _busy = false;
  (bool, String)? _result;

  SkyCard get card => widget.card;

  Future<void> _save(SkyCard c) => ref.read(skySettingsProvider.notifier).updateCard(c);

  Future<void> _pickGift() async {
    final gift = await GiftCatalogDialog.show(context, pick: true);
    if (gift == null || !mounted) return;
    // Новый подарок целиком: без id (по названию) старый id не остаётся.
    await _save(SkyCard(
      actionId: card.actionId,
      enabled: card.enabled,
      giftName: gift.displayName,
      giftId: gift.id.isEmpty ? null : gift.id,
      imageUrl: gift.imageUrl,
      strength: card.strength,
      seconds: card.seconds,
      cooldown: card.cooldown,
      repeat: card.repeat,
      likesEvery: card.likesEvery,
    ));
  }

  Future<void> _test() async {
    setState(() => _busy = true);
    final r = await ref.read(skyEngineProvider).test(card);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _result = r;
    });
  }

  @override
  Widget build(BuildContext context) {
    final a = card.action;
    final tierColor = SkyColors.tier(a.tier);
    final ready = ref.watch(minecraftLinkProvider.select((l) => l.skyBlocker == null));
    return _SkyPanel(
      key: Key('sky-card-${a.id}'),
      borderColor: card.enabled ? tierColor.withAlpha(90) : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [tierColor.withAlpha(70), SkyColors.extra.withAlpha(50)],
                  ),
                ),
                child: Icon(skyIcon(a.id), color: tierColor, size: 26),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(a.title,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: SkyColors.text)),
                    const SizedBox(height: 4),
                    Wrap(spacing: 6, runSpacing: 4, children: [
                      TagChip(label: a.tier.label, color: tierColor),
                      if (a.movement) const TagChip(label: 'движение', color: AppColors.textMuted),
                      if (a.help) const TagChip(label: 'помогает', color: AppColors.success),
                    ]),
                  ],
                ),
              ),
              Switch(
                key: Key('sky-enabled-${a.id}'),
                value: card.enabled,
                onChanged: (v) => _save(card.copyWith(enabled: v)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(a.description, style: const TextStyle(fontSize: 13, color: AppColors.textMuted, height: 1.3)),
          const SizedBox(height: 12),
          Row(
            children: [
              GiftAvatar(imageUrl: card.imageUrl, size: 36),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  card.hasGift ? card.giftName : 'Подарок не выбран',
                  key: Key('sky-gift-name-${a.id}'),
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: card.hasGift ? SkyColors.text : AppColors.textFaint,
                  ),
                ),
              ),
              TextButton(
                key: Key('sky-gift-${a.id}'),
                onPressed: _pickGift,
                child: Text(card.hasGift ? 'Сменить' : 'Выбрать'),
              ),
              if (card.hasGift)
                IconButton(
                  key: Key('sky-gift-clear-${a.id}'),
                  tooltip: 'Убрать подарок',
                  onPressed: () => _save(card.copyWith(clearGift: true)),
                  icon: const Icon(Icons.close_rounded, size: 18),
                ),
            ],
          ),
          if (card.isLikes) ...[
            const SizedBox(height: 6),
            _Stepper(
              key: Key('sky-likes-${a.id}'),
              label: 'Лайков на срабатывание',
              value: card.likesEvery,
              min: 1,
              max: 1000,
              step: card.likesEvery >= 100 ? 50 : 5,
              onChanged: (v) => _save(card.copyWith(likesEvery: v)),
            ),
          ],
          const SizedBox(height: 8),
          _SliderRow(
            key: Key('sky-strength-${a.id}'),
            label: 'Сила',
            valueText: '×${card.strength.toStringAsFixed(2)}',
            value: card.strength,
            min: 0.5,
            max: 2.0,
            divisions: 6,
            onChanged: (v) => _save(card.copyWith(strength: (v * 4).round() / 4)),
          ),
          _SliderRow(
            key: Key('sky-seconds-${a.id}'),
            label: 'Время',
            valueText: '${card.effectiveSeconds} с',
            value: card.effectiveSeconds.toDouble().clamp(1, 60).toDouble(),
            min: 1,
            max: 60,
            divisions: 59,
            onChanged: (v) => _save(card.copyWith(seconds: v.round())),
          ),
          _SliderRow(
            key: Key('sky-cooldown-${a.id}'),
            label: 'Перезарядка',
            valueText: '${card.effectiveCooldown} с',
            value: card.effectiveCooldown.toDouble().clamp(1, 120).toDouble(),
            min: 1,
            max: 120,
            divisions: 119,
            onChanged: (v) => _save(card.copyWith(cooldown: v.round())),
          ),
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            crossAxisAlignment: WrapCrossAlignment.center,
            spacing: 8,
            runSpacing: 6,
            children: [
              Wrap(
                crossAxisAlignment: WrapCrossAlignment.center,
                spacing: 8,
                children: [
                  const Text('Повтор, пока идёт:', style: TextStyle(fontSize: 13, color: AppColors.textMuted)),
                  DropdownButton<String>(
                    key: Key('sky-repeat-${a.id}'),
                    value: card.repeat,
                    dropdownColor: SkyColors.card,
                    items: [
                      for (final r in skyRepeatRules.entries) DropdownMenuItem(value: r.key, child: Text(r.value)),
                    ],
                    onChanged: (v) {
                      if (v != null) _save(card.copyWith(repeat: v));
                    },
                  ),
                ],
              ),
              FilledButton.tonal(
                key: Key('sky-test-${a.id}'),
                onPressed: ready && !_busy ? _test : null,
                child: Text(_busy ? 'Проверка…' : 'Проверить'),
              ),
            ],
          ),
          if (_result != null)
            Text(
              _result!.$2,
              key: Key('sky-test-result-${a.id}'),
              style: TextStyle(fontSize: 12, color: _result!.$1 ? AppColors.success : AppColors.danger),
            ),
        ],
      ),
    );
  }
}

class _SliderRow extends StatelessWidget {
  const _SliderRow({
    super.key,
    required this.label,
    required this.valueText,
    required this.value,
    required this.min,
    required this.max,
    required this.divisions,
    required this.onChanged,
  });

  final String label;
  final String valueText;
  final double value;
  final double min;
  final double max;
  final int divisions;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) => Row(
        children: [
          SizedBox(
            width: 92,
            child: Text(label, style: const TextStyle(fontSize: 13, color: AppColors.textMuted)),
          ),
          Expanded(
            child: Slider(
              value: value.clamp(min, max).toDouble(),
              min: min,
              max: max,
              divisions: divisions,
              onChanged: onChanged,
            ),
          ),
          SizedBox(
            width: 56,
            child: Text(valueText,
                textAlign: TextAlign.right,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: SkyColors.text)),
          ),
        ],
      );
}

class _Stepper extends StatelessWidget {
  const _Stepper({
    super.key,
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.step,
    required this.onChanged,
  });

  final String label;
  final int value;
  final int min;
  final int max;
  final int step;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(fontSize: 13, color: AppColors.textMuted))),
          IconButton(
            onPressed: value > min ? () => onChanged((value - step).clamp(min, max).toInt()) : null,
            icon: const Icon(Icons.remove_rounded, size: 18),
          ),
          Text('$value', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: SkyColors.text)),
          IconButton(
            onPressed: value < max ? () => onChanged((value + step).clamp(min, max).toInt()) : null,
            icon: const Icon(Icons.add_rounded, size: 18),
          ),
        ],
      );
}

// ----------------------------------------------------------------- журнал

class _JournalCard extends ConsumerWidget {
  const _JournalCard();

  static Color _color(String state) => switch (state) {
        'started' => AppColors.success,
        'finished' => AppColors.textMuted,
        'deferred' => AppColors.warning,
        'rejected' => AppColors.danger,
        _ => SkyColors.accent,
      };

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final entries = ref.watch(skyJournalProvider);
    return _SkyPanel(
      key: const Key('sky-journal'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text('Журнал действий',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: SkyColors.text)),
              ),
              if (entries.isNotEmpty)
                TextButton(
                  onPressed: () => ref.read(skyJournalProvider.notifier).clear(),
                  child: const Text('Очистить'),
                ),
            ],
          ),
          const SizedBox(height: 6),
          if (entries.isEmpty)
            const Text('Здесь появятся ответы игры: принято, запущено, отложено (и почему), отклонено, завершено.',
                style: TextStyle(fontSize: 13, color: AppColors.textFaint)),
          for (final e in entries.take(30))
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 64,
                    child: Text(
                      '${e.at.hour.toString().padLeft(2, '0')}:${e.at.minute.toString().padLeft(2, '0')}:'
                      '${e.at.second.toString().padLeft(2, '0')}',
                      style: const TextStyle(fontSize: 12, color: AppColors.textFaint),
                    ),
                  ),
                  Icon(skyIcon(e.actionId), size: 16, color: SkyColors.accent),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      '${e.title}${e.viewer.isEmpty ? '' : ' · ${e.viewer}'}${e.reason.isEmpty ? '' : ' — ${e.reason}'}',
                      style: const TextStyle(fontSize: 13, color: SkyColors.text),
                    ),
                  ),
                  const SizedBox(width: 8),
                  TagChip(label: skyAckLabel(e.state), color: _color(e.state)),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _AboutCard extends StatelessWidget {
  const _AboutCard();

  @override
  Widget build(BuildContext context) => const _SkyPanel(
        key: Key('sky-about'),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Как играть', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: SkyColors.text)),
            SizedBox(height: 8),
            Text(
              '1. Распакуйте набор DirronParkour-kit.zip: мод — в mods, мир DirronSky — в saves (рядом с DirronParkour).\n'
              '2. Откройте мир DirronSky, в программе включите связь с игрой и нажмите «Старт» '
              '(или /sky start в игре). Тренировочный круг — «Тренировка».\n'
              '3. Элитры выдаются сами. Пролетайте кольца по порядку: голубые — ускорение, '
              'облака снизу — восходящий поток. После ошибки — возврат на контрольную точку сектора '
              'и 3 секунды защиты.\n'
              '4. Клавиша быстрого рестарта работает прямо в игре. Пауза останавливает время и эффекты.\n'
              '5. Одновременно идут не больше двух эффектов движения и одно дорогое событие — '
              'остальные ждут в очереди (до 45 с), причины видны в журнале.',
              style: TextStyle(fontSize: 13, height: 1.45, color: AppColors.textMuted),
            ),
          ],
        ),
      );
}
