import 'package:flutter/material.dart';

import '../../../features/parkour/action_catalog.dart';
import '../../theme/app_colors.dart';

/// Сливовый фон окон паркура.
const plum = Color(0xFF2B1638);
const plumHigh = Color(0xFF3A1F4B);

/// Цвет группы: перемещение — фиолетовый, помощь — лайм, помеха — коралл.
Color categoryColor(ActionCategory c) => switch (c) {
      ActionCategory.move => AppColors.accent,
      ActionCategory.help => AppColors.success,
      ActionCategory.hindrance => AppColors.danger,
    };

IconData actionIcon(String id) => switch (id) {
      'room_forward' => Icons.fast_forward_rounded,
      'room_back' => Icons.fast_rewind_rounded,
      'big_rollback' => Icons.history_rounded,
      'restart_room' => Icons.restart_alt_rounded,
      'fall_rescue' => Icons.health_and_safety_rounded,
      'personal_checkpoint' => Icons.flag_rounded,
      'champion_jump' => Icons.keyboard_double_arrow_up_rounded,
      'sprint' => Icons.directions_run_rounded,
      'heavy_boots' => Icons.fitness_center_rounded,
      'freeze' => Icons.ac_unit_rounded,
      'push' => Icons.air_rounded,
      'trampoline' => Icons.vertical_align_top_rounded,
      'soft_landing' => Icons.paragliding_rounded,
      'safety_platform' => Icons.layers_rounded,
      'viewer_bridge' => Icons.add_road_rounded,
      'secret_shortcut' => Icons.call_split_rounded,
      'vanishing_step' => Icons.visibility_off_rounded,
      'show_route' => Icons.route_rounded,
      'shield' => Icons.shield_rounded,
      'second_chance' => Icons.hourglass_top_rounded,
      'to_last_level' => Icons.emoji_events_rounded,
      'to_first_level' => Icons.first_page_rounded,
      'super_push' => Icons.rocket_launch_rounded,
      'lightning' => Icons.bolt_rounded,
      _ => Icons.bolt_rounded,
    };

/// Крупный значок действия. У «СУПЕР СИЛЬНОГО ТОЛЧКА» — особый: градиент
/// и метка ×3, чтобы его нельзя было спутать с обычным «Толчком».
/// Картинка для «Лайков» и «Подписки» вместо подарка.
String? socialImageUrl(String? giftId) => switch (giftId) {
      'likes' => 'asset:assets/social/likes.png',
      'follow' => 'asset:assets/social/follow.png',
      _ => null,
    };

/// Картинка действия из assets/actions/<id>.png; если её нет — общая
/// картинка (молния), а если и её нет — значок Material.
String actionImagePath(String actionId) => 'assets/actions/$actionId.png';

class ActionBadge extends StatelessWidget {
  const ActionBadge({super.key, required this.action, this.size = 52});

  final ParkourAction action;
  final double size;

  @override
  Widget build(BuildContext context) {
    final color = categoryColor(action.category);
    final superPush = action.id == 'super_push';
    final materialIcon = Icon(actionIcon(action.id), color: color, size: size * 0.55);
    final picture = Image.asset(
      actionImagePath(action.id),
      key: Key('action-image-${action.id}'),
      width: size * 0.82,
      height: size * 0.82,
      fit: BoxFit.contain,
      filterQuality: FilterQuality.medium,
      errorBuilder: (_, __, ___) => Image.asset(
        actionImagePath('fallback'),
        width: size * 0.82,
        height: size * 0.82,
        fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => materialIcon,
      ),
    );
    final box = Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: superPush ? null : color.withAlpha(38),
        gradient: superPush
            ? const LinearGradient(
                colors: [Color(0x55FF7A90), Color(0x55FFC857)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : null,
        borderRadius: BorderRadius.circular(size * 0.3),
        border: Border.all(color: superPush ? const Color(0xFFFFC857) : color.withAlpha(150)),
        boxShadow: superPush ? [BoxShadow(color: const Color(0xFFFF7A90).withAlpha(110), blurRadius: 14)] : null,
      ),
      child: picture,
    );
    if (!superPush) return box;
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          box,
          Positioned(
            right: -6,
            top: -6,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
              decoration: BoxDecoration(
                color: AppColors.onAccent,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFFFFC857)),
              ),
              child: const Text('×3',
                  style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: Color(0xFFFFC857))),
            ),
          ),
        ],
      ),
    );
  }
}

/// Значок подарка: картинка TikTok или нейтральная иконка.
class GiftAvatar extends StatelessWidget {
  const GiftAvatar({super.key, this.imageUrl, this.size = 36});

  final String? imageUrl;
  final double size;

  @override
  Widget build(BuildContext context) {
    final fallback = Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: AppColors.accentAlt.withAlpha(36),
        shape: BoxShape.circle,
      ),
      child: Icon(Icons.redeem_rounded, color: AppColors.accentAlt, size: size * 0.55),
    );
    final url = imageUrl;
    if (url == null) return fallback;
    // Свои картинки программы («Лайки», «Подписка»): asset:путь.
    if (url.startsWith('asset:')) {
      return Image.asset(url.substring(6),
          width: size, height: size, fit: BoxFit.contain, errorBuilder: (context, error, stack) => fallback);
    }
    return SizedBox(
      width: size,
      height: size,
      child: Image.network(
        url,
        width: size,
        height: size,
        fit: BoxFit.contain,
        errorBuilder: (context, error, stack) => fallback,
      ),
    );
  }
}
