import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/events/gift_event.dart';
import '../../../core/providers.dart';
import '../../../features/events/event_log.dart';
import '../../../features/minecraft/minecraft_link.dart';
import '../../../features/parkour/action_catalog.dart';
import '../../../features/parkour/gift_catalog.dart';
import '../../../features/parkour/parkour_engine.dart';
import '../../../features/parkour/parkour_rules.dart';
import '../../theme/app_colors.dart';
import 'action_look.dart';
import 'action_picker_dialog.dart';
import 'gift_catalog_dialog.dart';

/// «Действия за подарки»: карточки сразу на экране. На каждой — выбор
/// подарка, параметры, «Проверить в игре», серия ×1000, переключатель и
/// удаление. «Добавить действие» только расширяет список.
class RulesTab extends ConsumerStatefulWidget {
  const RulesTab({super.key});

  @override
  ConsumerState<RulesTab> createState() => _RulesTabState();
}

class _RulesTabState extends ConsumerState<RulesTab> {
  final Map<String, ActionOutcome> _results = {};
  final Set<String> _busy = {};

  Future<void> _save(GiftRule rule) async {
    final error = await ref.read(parkourRulesProvider.notifier).upsert(rule);
    if (error != null) ref.read(noticeServiceProvider).error(error);
  }

  Future<void> _pickGift(GiftRule rule) async {
    final gift = await GiftCatalogDialog.show(context, pick: true);
    if (gift == null || !mounted) return;
    await _save(GiftRule(
      id: rule.id,
      giftName: gift.displayName,
      giftId: gift.id.isEmpty ? null : gift.id,
      imageUrl: gift.imageUrl,
      actionId: rule.actionId,
      params: rule.params,
      enabled: rule.enabled,
    ));
  }

  Future<void> _addAction() async {
    final action = await ActionPickerDialog.show(context);
    if (action == null || !mounted) return;
    await _save(GiftRule(id: newRuleId(), actionId: action.id, params: action.defaults()));
  }

  Future<void> _test(GiftRule rule) async {
    setState(() => _busy.add(rule.id));
    final result = await ref.read(parkourEngineProvider).test(rule);
    if (!mounted) return;
    setState(() {
      _busy.remove(rule.id);
      _results[rule.id] = result;
    });
  }

  Future<void> _series(GiftRule rule) async {
    setState(() {
      _busy.add(rule.id);
      _results.remove(rule.id);
    });
    final blocker = ref.read(minecraftLinkProvider).parkourBlocker;
    final id = await ref.read(parkourEngineProvider).testSeries(rule);
    if (!mounted) return;
    setState(() {
      _busy.remove(rule.id);
      if (id == null) _results[rule.id] = ActionOutcome(false, blocker ?? 'Серия не запущена');
    });
  }

  @override
  Widget build(BuildContext context) {
    final rules = ref.watch(parkourRulesProvider).rules;
    final catalog = ref.watch(giftCatalogProvider).catalog;
    final activity = ref.watch(parkourActivityProvider);
    final log = ref.watch(eventLogProvider);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Wrap(
          spacing: 10,
          runSpacing: 10,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            FilledButton.icon(
              key: const Key('open-gift-catalog'),
              onPressed: () => GiftCatalogDialog.show(context),
              icon: const Icon(Icons.redeem_rounded, size: 18),
              label: const Text('Каталог подарков'),
            ),
            OutlinedButton.icon(
              key: const Key('add-action'),
              onPressed: _addAction,
              icon: const Icon(Icons.add_rounded, size: 18),
              label: const Text('Добавить действие'),
            ),
            const Text(
              'Одна штука подарка — одно срабатывание: «Роза ×1000» = 1000 действий.',
              style: TextStyle(fontSize: 13, color: AppColors.textFaint),
            ),
          ],
        ),
        const SizedBox(height: 14),
        if (rules.isEmpty)
          const Text('Карточек нет — нажмите «Добавить действие».',
              style: TextStyle(fontSize: 14, color: AppColors.textMuted))
        else
          LayoutBuilder(builder: (context, constraints) {
            // Карточки в ряд: от 380 px на карточку (уже — не помещаются кнопки), до 5 в строке.
            final columns = (constraints.maxWidth / 380).floor().clamp(1, 5).toInt();
            final width = (constraints.maxWidth - (columns - 1) * 14) / columns;
            return Wrap(
              spacing: 14,
              runSpacing: 14,
              children: [
                for (final (index, rule) in rules.indexed)
                  _Movable(
                    key: Key('rule-move-${rule.id}'),
                    rule: rule,
                    width: width,
                    // Перетащили другую карточку сюда — она встаёт на это место.
                    onDropped: (id) => ref.read(parkourRulesProvider.notifier).move(id, index),
                    child: _ActionCard(
                      key: Key('rule-${rule.id}'),
                      rule: rule,
                      imageUrl: rule.imageUrl ??
                          socialImageUrl(rule.giftId) ??
                          (rule.giftId == null ? null : catalog.byId(rule.giftId!)?.imageUrl),
                      record: activity[rule.id] == null ? null : log.byId(activity[rule.id]!),
                      result: _results[rule.id],
                      busy: _busy.contains(rule.id),
                      onPickGift: () => _pickGift(rule),
                      onChanged: _save,
                      onTest: () => _test(rule),
                      onSeries: () => _series(rule),
                      onDelete: () => ref.read(parkourRulesProvider.notifier).remove(rule.id),
                      onLeft: index == 0
                          ? null
                          : () => ref.read(parkourRulesProvider.notifier).move(rule.id, index - 1),
                      onRight: index == rules.length - 1
                          ? null
                          : () => ref.read(parkourRulesProvider.notifier).move(rule.id, index + 1),
                    ),
                  ),
              ],
            );
          }),
      ],
    );
  }
}

/// Карточку можно перетащить мышью (зажать и тянуть) на место другой.
class _Movable extends StatelessWidget {
  const _Movable({super.key, required this.rule, required this.width, required this.onDropped, required this.child});

  final GiftRule rule;
  final double width;
  final ValueChanged<String> onDropped;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return DragTarget<String>(
      onWillAcceptWithDetails: (d) => d.data != rule.id,
      onAcceptWithDetails: (d) => onDropped(d.data),
      builder: (context, candidates, _) {
        final card = SizedBox(width: width, child: child);
        // Рамка поверх карточки, а не вокруг: размер карточки не меняется.
        return Container(
          foregroundDecoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: candidates.isNotEmpty ? AppColors.accent : Colors.transparent,
              width: 2,
            ),
          ),
          child: LongPressDraggable<String>(
            data: rule.id,
            delay: const Duration(milliseconds: 250),
            feedback: Material(
              color: Colors.transparent,
              child: Opacity(opacity: 0.85, child: SizedBox(width: width, child: child)),
            ),
            childWhenDragging: Opacity(opacity: 0.3, child: card),
            child: card,
          ),
        );
      },
    );
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    super.key,
    required this.rule,
    required this.imageUrl,
    required this.record,
    required this.result,
    required this.busy,
    required this.onPickGift,
    required this.onChanged,
    required this.onTest,
    required this.onSeries,
    required this.onDelete,
    this.onLeft,
    this.onRight,
  });

  final GiftRule rule;
  final String? imageUrl;
  final GiftEvent? record;
  final ActionOutcome? result;
  final bool busy;
  final VoidCallback onPickGift;
  final ValueChanged<GiftRule> onChanged;
  final VoidCallback onTest;
  final VoidCallback onSeries;
  final VoidCallback onDelete;
  final VoidCallback? onLeft;
  final VoidCallback? onRight;

  @override
  Widget build(BuildContext context) {
    final action = rule.action!;
    final color = categoryColor(action.category);
    final status = _statusLine();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: action.id == 'super_push' ? const Color(0xFF2F1830) : AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withAlpha(rule.enabled ? 150 : 50), width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              ActionBadge(action: action, size: 46),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(action.title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w900,
                          color: rule.enabled ? AppColors.text : AppColors.textFaint,
                        )),
                    Text(action.hint,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 12, color: color)),
                  ],
                ),
              ),
              Switch(
                key: Key('rule-enabled-${rule.id}'),
                value: rule.enabled,
                onChanged: (v) => onChanged(rule.copyWith(enabled: v)),
              ),
              IconButton(
                key: Key('rule-left-${rule.id}'),
                tooltip: 'Передвинуть левее',
                padding: EdgeInsets.zero,
                iconSize: 20,
                constraints: const BoxConstraints.tightFor(width: 26, height: 32),
                onPressed: onLeft,
                icon: const Icon(Icons.chevron_left_rounded),
              ),
              IconButton(
                key: Key('rule-right-${rule.id}'),
                tooltip: 'Передвинуть правее',
                padding: EdgeInsets.zero,
                iconSize: 20,
                constraints: const BoxConstraints.tightFor(width: 26, height: 32),
                onPressed: onRight,
                icon: const Icon(Icons.chevron_right_rounded),
              ),
              IconButton(
                key: Key('rule-delete-${rule.id}'),
                tooltip: 'Удалить карточку',
                onPressed: onDelete,
                icon: const Icon(Icons.delete_outline_rounded, color: AppColors.danger),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Material(
            color: AppColors.surfaceAlt,
            borderRadius: BorderRadius.circular(14),
            child: InkWell(
              key: Key('rule-gift-${rule.id}'),
              borderRadius: BorderRadius.circular(14),
              onTap: onPickGift,
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                      color: rule.hasGift ? AppColors.border : AppColors.accentAlt.withAlpha(140)),
                ),
                child: Row(
                  children: [
                    GiftAvatar(imageUrl: imageUrl, size: 44),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            rule.hasGift ? rule.giftName : 'Выбрать подарок',
                            key: Key('rule-gift-name-${rule.id}'),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                              color: rule.hasGift ? AppColors.text : AppColors.accentAlt,
                            ),
                          ),
                          Text(
                            rule.hasGift
                                ? (rule.giftId == null ? 'по названию' : 'выбран из каталога')
                                : 'одно нажатие в каталоге',
                            style: const TextStyle(fontSize: 12, color: AppColors.textFaint),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_right_rounded, color: AppColors.textMuted),
                  ],
                ),
              ),
            ),
          ),
          if (rule.isFollow) ...[
            const SizedBox(height: 6),
            Row(
              children: [
                const Expanded(
                  child: Text('Засчитывать повторную подписку (отписался — подписался снова)',
                      style: TextStyle(fontSize: 13, color: AppColors.textMuted)),
                ),
                Switch(
                  key: Key('rule-refollow-${rule.id}'),
                  value: rule.repeatFollow,
                  onChanged: (v) => onChanged(rule.copyWith(repeatFollow: v)),
                ),
              ],
            ),
          ],
          if (rule.isLikes) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                const Expanded(
                  child: Text('Лайков на одно срабатывание',
                      style: TextStyle(fontSize: 14, color: AppColors.text)),
                ),
                SizedBox(
                  width: 110,
                  child: TextFormField(
                    key: Key('rule-likes-${rule.id}'),
                    initialValue: '${rule.likesEvery}',
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppColors.text),
                    decoration: const InputDecoration(isDense: true, suffixText: '❤'),
                    onChanged: (v) {
                      final n = int.tryParse(v);
                      if (n != null && n >= 1) onChanged(rule.copyWith(likesEvery: n.clamp(1, 100000).toInt()));
                    },
                  ),
                ),
              ],
            ),
          ],
          if (action.params.isNotEmpty) ...[
            const SizedBox(height: 10),
            for (final p in action.params) _paramRow(p),
          ],
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              FilledButton.icon(
                key: Key('rule-test-${rule.id}'),
                onPressed: busy ? null : onTest,
                icon: const Icon(Icons.play_arrow_rounded, size: 20),
                label: const Text('Проверить в игре'),
              ),
              OutlinedButton.icon(
                key: Key('rule-series-${rule.id}'),
                onPressed: busy ? null : onSeries,
                icon: const Icon(Icons.all_inclusive_rounded, size: 18),
                label: const Text('Серия ×1000'),
              ),
            ],
          ),
          if (status != null) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                Icon(status.$2 ? Icons.check_circle_rounded : Icons.info_outline_rounded,
                    size: 18, color: status.$3),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    status.$1,
                    key: Key('rule-status-${rule.id}'),
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: status.$3),
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  /// (текст, успех, цвет)
  (String, bool, Color)? _statusLine() {
    final r = result;
    final rec = record;
    if (rec != null && rec.actionState != ActionState.none) {
      final text = rec.actionText ?? '';
      return switch (rec.actionState) {
        ActionState.done => (text, true, AppColors.success),
        ActionState.pending => (text, false, AppColors.warning),
        _ => (text, false, AppColors.danger),
      };
    }
    if (r != null) return (r.text, r.ok, r.ok ? AppColors.success : AppColors.danger);
    return null;
  }

  Widget _paramRow(ActionParam p) {
    final value = p.normalize(rule.params[p.key]);
    void set(Object v) => onChanged(rule.copyWith(params: {...rule.params, p.key: p.normalize(v)}));
    final Widget control;
    if (p.kind == ParamKind.choice) {
      control = Wrap(
        spacing: 4,
        runSpacing: 4,
        children: [
          for (final e in p.choices.entries)
            ChoiceChip(
              key: Key('param-${rule.id}-${p.key}-${e.key}'),
              label: Text(e.value),
              selected: value == e.key,
              showCheckmark: false,
              visualDensity: VisualDensity.compact,
              selectedColor: AppColors.accent,
              labelStyle: TextStyle(fontSize: 12, color: value == e.key ? AppColors.onAccent : AppColors.text),
              onSelected: (_) => set(e.key),
            ),
        ],
      );
    } else {
      control = Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            key: Key('param-${rule.id}-${p.key}-minus'),
            visualDensity: VisualDensity.compact,
            onPressed: () => set((value as num) - p.step),
            icon: const Icon(Icons.remove_circle_outline_rounded, size: 20, color: AppColors.textMuted),
          ),
          SizedBox(
            width: 72,
            child: Text(p.format(value),
                key: Key('param-${rule.id}-${p.key}-value'),
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.text)),
          ),
          IconButton(
            key: Key('param-${rule.id}-${p.key}-plus'),
            visualDensity: VisualDensity.compact,
            onPressed: () => set((value as num) + p.step),
            icon: const Icon(Icons.add_circle_outline_rounded, size: 20, color: AppColors.textMuted),
          ),
        ],
      );
    }
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Wrap(
        spacing: 8,
        crossAxisAlignment: WrapCrossAlignment.center,
        children: [
          SizedBox(
            width: 120,
            child: Text(p.label, style: const TextStyle(fontSize: 13, color: AppColors.textMuted)),
          ),
          control,
        ],
      ),
    );
  }
}
