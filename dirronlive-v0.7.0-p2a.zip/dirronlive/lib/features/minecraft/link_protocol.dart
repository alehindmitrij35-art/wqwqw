import 'dart:convert';

import '../../core/events/gift_event.dart';

/// Протокол обмена с модом Dirronlive Bridge (JSON-сообщения по WebSocket).
///
/// Мод → программа:
///   {"type":"hello","protocol":1,"modVersion":"1.0.0",
///    "minecraftVersion":"1.21.1","worldReady":false}
///   {"type":"world","worldReady":true}
///   {"type":"ack","id":"…"}
///   {"type":"parkour","available":true,"room":12,"finished":false,"falls":3,"seconds":95}
///   {"type":"actionResult","id":"…","ok":true,"result":"Комната 12 → 11","room":11}
///
/// Программа → мод:
///   {"type":"welcome","app":"Dirronlive","protocol":2}
///   {"type":"gift","id":"…","viewerName":"…","giftName":"Роза","count":1}
///   {"type":"action","id":"…","action":"room_back","params":{"rooms":1},
///    "label":"Роза","viewerName":"Alex","test":false}
///   {"type":"countdown","id":"…","title":"…","seconds":10}
///   {"type":"countdownCancel","id":"…","text":"…"}
///
/// «Небесный разлом» (полёт на элитрах):
///   программа → мод: skyCommand {id, cmd}, skySettings {profile, restartKey,
///   reduceFlashes}, skyAction {id, action, strength, seconds, cooldown, repeat, viewer}
///   мод → программа: sky {map, phase, sector, ring, ms, errors, effects…},
///   skyResult {id, cmd, ok, text}, skyAck {id, action, state, reason}
abstract final class LinkProtocol {
  static const version = 2;
  static const defaultPort = 8765;

  static String welcome() =>
      jsonEncode({'type': 'welcome', 'app': 'Dirronlive', 'protocol': version});

  /// Сообщение моду. [deliveryId] — уникальный ID этой отправки (по нему
  /// приходит подтверждение), [units] — сколько подарков применить сейчас.
  static String gift({
    required String deliveryId,
    required GiftEvent record,
    required int units,
    int? comboTotal,
  }) =>
      jsonEncode({
        'type': 'gift',
        'id': deliveryId,
        'viewerName': record.viewerName,
        'giftName': record.giftName,
        'count': units,
        if (comboTotal != null) 'combo': true,
        if (comboTotal != null) 'comboTotal': comboTotal,
      });

  static String action({
    required String id,
    required String action,
    required Map<String, Object?> params,
    required String label,
    required String viewerName,
    required bool test,
    int total = 1,
  }) =>
      jsonEncode({
        'type': 'action',
        'id': id,
        'action': action,
        'params': params,
        'label': label,
        'viewerName': viewerName,
        'test': test,
        'total': total,
      });

  /// Управление заездом: start, restart, pause, resume, checkpoint, stop, training.
  static String skyCommand(String id, String cmd) => jsonEncode({'type': 'skyCommand', 'id': id, 'cmd': cmd});

  static String skySettings({required String profile, required String restartKey, required bool reduceFlashes}) =>
      jsonEncode({
        'type': 'skySettings',
        'profile': profile,
        'restartKey': restartKey,
        'reduceFlashes': reduceFlashes,
      });

  /// Действие зрителя в полёте. Один [id] выполняется в моде один раз.
  static String skyAction({
    required String id,
    required String action,
    required double strength,
    required int seconds,
    required int cooldown,
    required String repeat,
    required String viewerName,
    required String label,
    required bool test,
  }) =>
      jsonEncode({
        'type': 'skyAction',
        'id': id,
        'action': action,
        'strength': strength,
        'seconds': seconds,
        'cooldown': cooldown,
        'repeat': repeat,
        'viewer': viewerName,
        'label': label,
        'test': test,
      });

  static String countdown(String id, String title, int seconds) => jsonEncode(
      {'type': 'countdown', 'id': id, 'title': title, 'seconds': seconds});

  /// Погода и время: time — day/sunrise/sunset/night/midnight, weather — clear/rain/thunder,
  /// freeze — остановить смену дня и погоды.
  static String world({String? time, String? weather, bool? freeze}) => jsonEncode({
        'type': 'world',
        if (time != null) 'time': time,
        if (weather != null) 'weather': weather,
        if (freeze != null) 'freeze': freeze,
      });

  /// Сообщение чата TikTok для чата игры.
  static String chat(String name, String text, String color) =>
      jsonEncode({'type': 'chat', 'name': name, 'text': text, 'color': color});

  static String countdownCancel(String id, String text) =>
      jsonEncode({'type': 'countdownCancel', 'id': id, 'text': text});

  /// Разбирает сообщение мода. Возвращает `null` для мусора.
  static ModMessage? parse(Object? data) {
    if (data is! String) return null;
    Object? decoded;
    try {
      decoded = jsonDecode(data);
    } on FormatException {
      return null;
    }
    if (decoded is! Map) return null;
    switch (decoded['type']) {
      case 'hello':
        return ModHello(
          modVersion: _string(decoded['modVersion']),
          minecraftVersion: _string(decoded['minecraftVersion']),
          worldReady: decoded['worldReady'] == true,
          parkourActions: decoded['parkourActions'] == true,
          actionQueue: decoded['actionQueue'] == true,
          sky: decoded['sky'] == true,
        );
      case 'sky':
        return ModSky(SkyInfo.fromJson(decoded));
      case 'skyAck':
        final id = decoded['id'];
        if (id is! String || id.isEmpty) return null;
        return ModSkyAck(
          id: id,
          action: _string(decoded['action']) ?? '',
          state: _string(decoded['state']) ?? '',
          reason: _string(decoded['reason']) ?? '',
        );
      case 'skyResult':
        final id = decoded['id'];
        if (id is! String || id.isEmpty) return null;
        return ModSkyResult(
          id: id,
          cmd: _string(decoded['cmd']) ?? '',
          ok: decoded['ok'] == true,
          text: _string(decoded['text']) ?? '',
        );
      case 'parkour':
        return ModParkour(ParkourInfo(
          available: decoded['available'] == true,
          room: _int(decoded['room']),
          finished: decoded['finished'] == true,
          falls: _int(decoded['falls']),
          seconds: _int(decoded['seconds']),
          roomFalls: _int(decoded['roomFalls']),
          bestRoom: _int(decoded['bestRoom']),
          bestSeconds: _int(decoded['bestSeconds']),
          queued: _int(decoded['queued']),
        ));
      case 'actionResult':
        final id = decoded['id'];
        if (id is! String || id.isEmpty) return null;
        return ModActionResult(
          id: id,
          ok: decoded['ok'] == true,
          result: _string(decoded['result']) ?? '',
          room: _int(decoded['room']),
          accepted: decoded.containsKey('accepted') ? _int(decoded['accepted']) : 1,
          done: decoded.containsKey('done') ? _int(decoded['done']) : (decoded['ok'] == true ? 1 : 0),
          queued: _int(decoded['queued']),
          finished: decoded['finished'] != false,
        );
      case 'world':
        return ModWorld(worldReady: decoded['worldReady'] == true);
      case 'ack':
        final id = decoded['id'];
        if (id is String && id.isNotEmpty) return ModAck(id);
        return null;
      default:
        return null;
    }
  }

  static String? _string(Object? value) =>
      value is String && value.isNotEmpty ? value : null;

  static int _int(Object? value) => value is num ? value.toInt() : 0;
}

/// Состояние карты «Dirron Parkour» в открытом мире.
class ParkourInfo {
  const ParkourInfo({
    required this.available,
    this.room = 0,
    this.finished = false,
    this.falls = 0,
    this.seconds = 0,
    this.roomFalls = 0,
    this.bestRoom = 0,
    this.bestSeconds = 0,
    this.queued = 0,
  });

  static const none = ParkourInfo(available: false);

  final bool available;
  final int room;
  final bool finished;
  final int falls;
  final int seconds;

  /// Падения в текущей комнате: попытка = roomFalls + 1.
  final int roomFalls;

  /// Рекорд забега: самая дальняя комната и лучшее время прохождения.
  final int bestRoom;
  final int bestSeconds;

  /// Сколько срабатываний ждёт в очереди мода.
  final int queued;
}

sealed class ModMessage {
  const ModMessage();
}

class ModHello extends ModMessage {
  const ModHello({
    this.modVersion,
    this.minecraftVersion,
    required this.worldReady,
    this.parkourActions = false,
    this.actionQueue = false,
    this.sky = false,
  });

  /// Мод умеет режим «Небесный разлом».
  final bool sky;

  final String? modVersion;
  final String? minecraftVersion;
  final bool worldReady;

  /// Мод 2.0+ умеет действия паркура.
  final bool parkourActions;

  /// Мод 2.1+: очередь серий без лимита.
  final bool actionQueue;
}

class ModParkour extends ModMessage {
  const ModParkour(this.info);

  final ParkourInfo info;
}

class ModActionResult extends ModMessage {
  const ModActionResult({
    required this.id,
    required this.ok,
    required this.result,
    this.room = 0,
    this.accepted = 1,
    this.done = 1,
    this.queued = 0,
    this.finished = true,
  });

  final String id;
  final bool ok;
  final String result;
  final int room;

  /// Сколько срабатываний принято в очередь, выполнено и ещё ждёт.
  final int accepted;
  final int done;
  final int queued;

  /// `false` — промежуточный прогресс серии.
  final bool finished;
}

class ModWorld extends ModMessage {
  const ModWorld({required this.worldReady});

  final bool worldReady;
}

class ModAck extends ModMessage {
  const ModAck(this.id);

  final String id;
}

class ModSky extends ModMessage {
  const ModSky(this.info);

  final SkyInfo info;
}

/// Ответ мода на действие в полёте: accepted, started, finished, deferred, rejected.
class ModSkyAck extends ModMessage {
  const ModSkyAck({required this.id, required this.action, required this.state, required this.reason});

  final String id;
  final String action;
  final String state;
  final String reason;
}

class ModSkyResult extends ModMessage {
  const ModSkyResult({required this.id, required this.cmd, required this.ok, required this.text});

  final String id;
  final String cmd;
  final bool ok;
  final String text;
}

/// Идущий эффект: id действия, сколько секунд осталось, от кого.
class SkyEffectInfo {
  const SkyEffectInfo({required this.id, required this.seconds, this.viewer = ''});

  final String id;
  final int seconds;
  final String viewer;
}

/// Состояние «Небесного разлома» в открытом мире.
class SkyInfo {
  const SkyInfo({
    this.map = 'absent',
    this.phase = 'idle',
    this.training = false,
    this.sector = 0,
    this.sectors = 0,
    this.ring = 0,
    this.rings = 0,
    this.passed = 0,
    this.total = 0,
    this.ms = 0,
    this.errors = 0,
    this.misses = 0,
    this.crashes = 0,
    this.bestMs = 0,
    this.countdown = 0,
    this.protection = false,
    this.effects = const [],
    this.queued = 0,
    this.problem = '',
    this.receivedAt,
  });

  static const none = SkyInfo();

  /// absent — в мире нет трассы, preparing — загружается или с ошибками, ready — готова.
  final String map;

  /// idle, countdown, running, paused, resuming, finished.
  final String phase;
  final bool training;
  final int sector;
  final int sectors;
  final int ring;
  final int rings;
  final int passed;
  final int total;
  final int ms;
  final int errors;
  final int misses;
  final int crashes;
  final int bestMs;
  final int countdown;
  final bool protection;
  final List<SkyEffectInfo> effects;
  final int queued;
  final String problem;

  /// Когда пришло: между сообщениями время досчитывается в программе.
  final DateTime? receivedAt;

  bool get available => map == 'ready';
  bool get running => phase == 'running';
  bool get paused => phase == 'paused';
  bool get active => phase == 'countdown' || phase == 'running' || phase == 'paused' || phase == 'resuming';

  /// Время заезда на момент [now] (идёт только в полёте).
  int msAt(DateTime now) {
    final at = receivedAt;
    if (!running || at == null) return ms;
    final extra = now.difference(at).inMilliseconds;
    return ms + (extra < 0 ? 0 : (extra > 1500 ? 1500 : extra));
  }

  static SkyInfo fromJson(Map<Object?, Object?> j, {DateTime? now}) {
    int n(Object? v) => v is num ? v.toInt() : 0;
    String s(Object? v, String d) => v is String && v.isNotEmpty ? v : d;
    final raw = j['effects'];
    return SkyInfo(
      map: s(j['map'], 'absent'),
      phase: s(j['phase'], 'idle'),
      training: j['training'] == true,
      sector: n(j['sector']),
      sectors: n(j['sectors']),
      ring: n(j['ring']),
      rings: n(j['rings']),
      passed: n(j['passed']),
      total: n(j['total']),
      ms: n(j['ms']),
      errors: n(j['errors']),
      misses: n(j['misses']),
      crashes: n(j['crashes']),
      bestMs: n(j['bestMs']),
      countdown: n(j['countdown']),
      protection: j['protection'] == true,
      effects: [
        if (raw is List)
          for (final e in raw)
            if (e is Map && e['id'] is String)
              SkyEffectInfo(id: e['id'] as String, seconds: n(e['seconds']), viewer: s(e['viewer'], '')),
      ],
      queued: n(j['queued']),
      problem: s(j['problem'], ''),
      receivedAt: now ?? DateTime.now(),
    );
  }
}
