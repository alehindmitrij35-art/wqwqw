package dev.dirronlive.sky.core;

import java.util.List;

/** Сектор трассы: 6–8 колец и своя контрольная точка. {@code index} — с 0. */
public record Sector(int index, String name, Checkpoint checkpoint, List<Ring> rings) {
    public Sector {
        rings = List.copyOf(rings);
        if (rings.isEmpty()) throw new IllegalArgumentException("в секторе нет колец");
    }

    public int first() {
        return rings.get(0).order();
    }

    public int last() {
        return rings.get(rings.size() - 1).order();
    }
}
