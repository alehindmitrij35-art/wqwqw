package dev.dirronlive.parkour.map;

/** Оформление десятка комнат: палитра и характер препятствий. */
public enum Theme {
    NEON("Бирюзовый неоновый город",
            "minecraft:cyan_concrete", "minecraft:white_concrete", "minecraft:sea_lantern",
            "minecraft:light_blue_concrete", "minecraft:cyan_stained_glass"),
    CORAL("Коралловые рифы",
            "minecraft:pink_concrete", "minecraft:white_concrete", "minecraft:sea_lantern",
            "minecraft:orange_concrete", "minecraft:prismarine_bricks"),
    HONEY("Медовая пасека",
            "minecraft:honeycomb_block", "minecraft:black_concrete", "minecraft:shroomlight",
            "minecraft:yellow_concrete", "minecraft:honey_block"),
    ICE("Ледяная аркада",
            "minecraft:packed_ice", "minecraft:light_blue_concrete", "minecraft:sea_lantern",
            "minecraft:blue_ice", "minecraft:magenta_stained_glass"),
    SLIME("Слайм-лаборатория",
            "minecraft:lime_concrete", "minecraft:black_concrete", "minecraft:verdant_froglight",
            "minecraft:slime_block", "minecraft:lime_stained_glass"),
    RASPBERRY("Малиновые сады",
            "minecraft:magenta_concrete", "minecraft:white_concrete", "minecraft:pearlescent_froglight",
            "minecraft:pink_concrete", "minecraft:cherry_leaves[persistent=true]"),
    FORGE("Огненная кузница",
            "minecraft:waxed_cut_copper", "minecraft:black_concrete", "minecraft:shroomlight",
            "minecraft:waxed_copper_block", "minecraft:furnace[lit=true,facing=north]"),
    AMETHYST("Аметистовые пещеры",
            "minecraft:amethyst_block", "minecraft:calcite", "minecraft:pearlescent_froglight",
            "minecraft:purple_concrete", "minecraft:tinted_glass"),
    CARNIVAL("Небесный карнавал",
            "minecraft:yellow_concrete", "minecraft:red_concrete", "minecraft:glowstone",
            "minecraft:light_blue_concrete", "minecraft:white_wool"),
    ARENA("Арена Dirron",
            "minecraft:purple_concrete", "minecraft:lime_concrete", "minecraft:verdant_froglight",
            "minecraft:black_concrete", "minecraft:magenta_stained_glass"),

    // ---- Dirron Parkour 2: шесть локаций по 15 комнат и «Разлом» (91–99).
    FOREST("Зачарованный лес",
            "minecraft:moss_block", "minecraft:stripped_oak_log[axis=x]", "minecraft:shroomlight",
            "minecraft:green_concrete", "minecraft:oak_leaves[persistent=true]"),
    MOUNTAIN("Снежные горы",
            "minecraft:snow_block", "minecraft:stone_bricks", "minecraft:sea_lantern",
            "minecraft:light_blue_concrete", "minecraft:spruce_leaves[persistent=true]"),
    DESERT("Пустыня фараонов",
            "minecraft:smooth_sandstone", "minecraft:cut_red_sandstone", "minecraft:glowstone",
            "minecraft:orange_terracotta", "minecraft:chiseled_sandstone"),
    REEF("Глубокий риф",
            "minecraft:prismarine_bricks", "minecraft:dark_prismarine", "minecraft:sea_lantern",
            "minecraft:light_blue_concrete", "minecraft:tube_coral_block"),
    NETHER("Огненный Ад",
            "minecraft:nether_bricks", "minecraft:blackstone", "minecraft:shroomlight",
            "minecraft:red_nether_bricks", "minecraft:crimson_hyphae[axis=y]"),
    END_ISLES("Острова Энда",
            "minecraft:end_stone_bricks", "minecraft:purpur_block", "minecraft:pearlescent_froglight",
            "minecraft:purple_concrete", "minecraft:obsidian"),
    RIFT("Разлом",
            "minecraft:crying_obsidian", "minecraft:obsidian", "minecraft:pearlescent_froglight",
            "minecraft:amethyst_block", "minecraft:purple_stained_glass");

    /** Локации второй карты по порядку (по 15 комнат). */
    public static final Theme[] SECOND = {FOREST, MOUNTAIN, DESERT, REEF, NETHER, END_ISLES};

    /** Комнат в локации второй карты. */
    public static final int SECOND_SPAN = 15;

    public final String title;
    /** Верх платформы. */
    public final String main;
    /** Контрастный край платформы. */
    public final String edge;
    /** Светящийся блок: подсветка снизу, цифры номера. */
    public final String light;
    /** Второй цвет темы (акценты, особые платформы). */
    public final String accent;
    /** Декор темы. */
    public final String decor;

    Theme(String title, String main, String edge, String light, String accent, String decor) {
        this.title = title;
        this.main = main;
        this.edge = edge;
        this.light = light;
        this.accent = accent;
        this.decor = decor;
    }

    public static Theme forRoom(int room) {
        int index = Math.max(0, Math.min(9, (room - 1) / 10));
        return values()[index];
    }

    /** Тема комнаты на карте [variant] (1 — Dirron Parkour, 2 — Dirron Parkour 2). */
    public static Theme forRoom(int variant, int room) {
        if (variant != 2) return forRoom(room);
        if (room == ParkourLayout.ROOMS) return ARENA;
        if (room > 90) return RIFT;
        return SECOND[Math.max(0, Math.min(5, (room - 1) / SECOND_SPAN))];
    }

    public boolean isSecondMap() {
        return ordinal() >= FOREST.ordinal();
    }
}
