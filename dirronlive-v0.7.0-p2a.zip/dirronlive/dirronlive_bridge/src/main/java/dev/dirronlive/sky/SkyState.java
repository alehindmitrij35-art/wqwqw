package dev.dirronlive.sky;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.datafixer.DataFixTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.PersistentState;

/** Данные режима «Небесный разлом» в сохранении мира: построена ли карта и рекорды. */
public final class SkyState extends PersistentState {
    public static final String ID = "dirron_sky";

    public boolean built;
    public final Map<UUID, Long> best = new HashMap<>();

    public static final PersistentState.Type<SkyState> TYPE = new PersistentState.Type<>(
            SkyState::new, SkyState::fromNbt, DataFixTypes.LEVEL);

    public static SkyState get(ServerWorld world) {
        return world.getPersistentStateManager().getOrCreate(TYPE, ID);
    }

    public long best(UUID id) {
        return best.getOrDefault(id, 0L);
    }

    public void setBest(UUID id, long ticks) {
        best.put(id, ticks);
        markDirty();
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        nbt.putBoolean("built", built);
        NbtCompound b = new NbtCompound();
        best.forEach((id, t) -> b.putLong(id.toString(), t));
        nbt.put("best", b);
        return nbt;
    }

    static SkyState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        SkyState s = new SkyState();
        s.built = nbt.getBoolean("built");
        NbtCompound b = nbt.getCompound("best");
        for (String key : b.getKeys()) {
            try {
                s.best.put(UUID.fromString(key), b.getLong(key));
            } catch (IllegalArgumentException ignored) {
                // повреждённая запись
            }
        }
        return s;
    }
}
