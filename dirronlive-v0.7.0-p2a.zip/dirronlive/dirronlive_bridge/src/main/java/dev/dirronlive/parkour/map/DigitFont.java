package dev.dirronlive.parkour.map;

/** Пиксельные цифры 3×5 для крупных номеров комнат. */
final class DigitFont {
    private DigitFont() {}

    private static final String[] DIGITS = {
            "111101101101111", // 0
            "010110010010111", // 1
            "111001111100111", // 2
            "111001111001111", // 3
            "101101111001001", // 4
            "111100111001111", // 5
            "111100111101111", // 6
            "111001001010010", // 7
            "111101111101111", // 8
            "111101111001111", // 9
    };

    /** Пиксель цифры: column 0..2, row 0..4 (0 — верх). */
    static boolean pixel(int digit, int column, int row) {
        return DIGITS[digit].charAt(row * 3 + column) == '1';
    }
}
