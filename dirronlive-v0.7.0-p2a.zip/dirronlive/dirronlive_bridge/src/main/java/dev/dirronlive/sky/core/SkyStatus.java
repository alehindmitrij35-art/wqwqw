package dev.dirronlive.sky.core;

import dev.dirronlive.bridge.MiniJson;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Состояние режима для программы: карта, заезд, сектор и кольцо, время,
 * ошибки, эффекты и очередь. Отправляется только при изменении (время —
 * не чаще раза в секунду), программа сама досчитывает секунды между ними.
 *
 * @param map    {@code absent} — в мире нет трассы, {@code preparing} — трасса
 *               загружается или с ошибками, {@code ready} — готова
 * @param phase  idle, countdown, running, paused, resuming, finished
 */
public record SkyStatus(String map, String phase, boolean training, int sector, int sectors, int ring, int rings,
                        int passed, int total, long ms, int errors, int misses, int crashes, long bestMs,
                        int countdown, boolean protection, List<Effect> effects, int queued, String problem) {

    /** Активный эффект: id, сколько секунд осталось, кто прислал. */
    public record Effect(String id, int seconds, String viewer) {}

    public static final SkyStatus ABSENT = new SkyStatus("absent", "idle", false, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            0, false, List.of(), 0, "");

    public SkyStatus {
        effects = effects == null ? List.of() : List.copyOf(effects);
        problem = problem == null ? "" : problem;
    }

    /** Отличается ли настолько, что стоит отправить (время — с шагом в секунду). */
    public boolean differs(SkyStatus o) {
        if (o == null) return true;
        return !map.equals(o.map) || !phase.equals(o.phase) || training != o.training || sector != o.sector
                || sectors != o.sectors || ring != o.ring || rings != o.rings || passed != o.passed || total != o.total
                || errors != o.errors || misses != o.misses || crashes != o.crashes || bestMs != o.bestMs
                || countdown != o.countdown || protection != o.protection || !effects.equals(o.effects)
                || queued != o.queued || !problem.equals(o.problem) || Math.abs(ms - o.ms) >= 1000;
    }

    public String toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("type", "sky");
        m.put("map", map);
        m.put("phase", phase);
        m.put("training", training);
        m.put("sector", sector);
        m.put("sectors", sectors);
        m.put("ring", ring);
        m.put("rings", rings);
        m.put("passed", passed);
        m.put("total", total);
        m.put("ms", ms);
        m.put("errors", errors);
        m.put("misses", misses);
        m.put("crashes", crashes);
        m.put("bestMs", bestMs);
        m.put("countdown", countdown);
        m.put("protection", protection);
        List<Object> es = new java.util.ArrayList<>();
        for (Effect e : effects) {
            Map<String, Object> em = new LinkedHashMap<>();
            em.put("id", e.id());
            em.put("seconds", e.seconds());
            em.put("viewer", e.viewer());
            es.add(em);
        }
        m.put("effects", es);
        m.put("queued", queued);
        m.put("problem", problem);
        return MiniJson.write(m);
    }
}
