package dev.dirronlive.sky;

import dev.dirronlive.sky.core.Ring;
import dev.dirronlive.sky.core.SkyEffects;
import dev.dirronlive.sky.core.Track;
import dev.dirronlive.sky.core.V3;
import dev.dirronlive.sky.core.Zone;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Кольца трассы рисуются на клиенте из данных (без блоков): одним пакетом
 * за кадр, только ближайшие по ходу полёта и только те, что в поле зрения.
 * Сколько колец впереди и насколько они гладкие, задаёт профиль
 * (Производительность / Баланс / Красота). Частицы потоков и ускорений —
 * с общим пределом на профиль; при низком FPS сокращаются только они,
 * кольца остаются.
 */
public final class SkyRender {
    private SkyRender() {}

    static final double VIEW = 220;

    // Цвета оформления: акцент #A78BFA, дополнительный #E879F9.
    static final int ACCENT = 0xA78BFA, EXTRA = 0xE879F9, BOOST = 0x5EEAD4, FINISH = 0xFDE68A, GATE = 0xE879F9;

    public static void register() {
        WorldRenderEvents.AFTER_TRANSLUCENT.register(SkyRender::render);
    }

    record Profile(int ahead, int segments, boolean glow) {}

    static Profile profile() {
        return switch (SkyConfig.settings.profile()) {
            case "performance" -> new Profile(4, 20, false);
            case "beauty" -> new Profile(10, 48, true);
            default -> new Profile(6, 32, true);
        };
    }

    static void render(WorldRenderContext ctx) {
        SkyWorld.ClientView view = SkyWorld.view;
        Track track = view.track();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (track == null || mc.player == null || view.player() == null || !mc.player.getUuid().equals(view.player())) return;
        MatrixStack stack = ctx.matrixStack();
        Matrix4f m = stack != null ? stack.peek().getPositionMatrix() : ctx.positionMatrix();
        VertexConsumerProvider consumers = ctx.consumers();
        if (m == null || consumers == null) return;
        Vec3d cam = ctx.camera().getPos();
        V3 eye = new V3(cam.x, cam.y, cam.z);
        Frustum frustum = ctx.frustum();
        Profile p = profile();
        float time = (mc.world == null ? 0 : mc.world.getTime()) + ctx.tickCounter().getTickDelta(true);
        boolean calm = SkyConfig.settings.reduceFlashes();
        VertexConsumer vc = consumers.getBuffer(RenderLayer.getLightning());
        int start = Math.min(view.nextRing(), track.ringCount());
        int end = Math.min(track.ringCount(), start + p.ahead());
        for (int i = start; i < end; i++) {
            Ring r = track.rings.get(i);
            if (r.center().distance(eye) > VIEW) continue;
            double rr = r.radius() * view.ringScale();
            if (frustum != null && !frustum.isVisible(box(r.center(), rr + 1))) continue;
            boolean next = i == start;
            int rgb = r.kind() == Ring.Kind.FINISH ? FINISH : r.isBoost() ? BOOST : next ? ACCENT : EXTRA;
            float pulse = next && !calm ? 0.75f + 0.25f * (float) Math.sin(time * 0.25) : 1f;
            int alpha = (int) ((next ? 200 : Math.max(60, 170 - (i - start) * 22)) * pulse);
            double width = 0.35 + 0.07 * rr;
            ring(vc, m, r.center().sub(eye), r.normal(), rr, width, p.segments(), rgb, alpha);
            if (p.glow() && next) ring(vc, m, r.center().sub(eye), r.normal(), rr + width, width * 1.6, p.segments(), rgb, alpha / 4);
        }
        for (SkyEffects.Gate g : view.gates()) {
            if (g.done()) continue;
            Ring r = g.ring();
            if (r.center().distance(eye) > VIEW) continue;
            ring(vc, m, r.center().sub(eye), r.normal(), r.radius(), 0.3, Math.max(16, p.segments() / 2), GATE, 190);
        }
        if (consumers instanceof VertexConsumerProvider.Immediate im) im.draw(RenderLayer.getLightning());
    }

    static Box box(V3 c, double r) {
        return new Box(c.x() - r, c.y() - r, c.z() - r, c.x() + r, c.y() + r, c.z() + r);
    }

    /** Кольцо-лента из четырёхугольников (с обеих сторон — видно и сзади). */
    static void ring(VertexConsumer vc, Matrix4f m, V3 c, V3 n, double radius, double width, int segments, int rgb, int alpha) {
        V3 u = n.cross(V3.UP);
        if (u.lengthSq() < 1e-6) u = n.cross(new V3(1, 0, 0));
        u = u.normalize();
        V3 v = n.cross(u).normalize();
        int r = (rgb >> 16) & 0xFF, g = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        double inner = radius, outer = radius + width;
        for (int i = 0; i < segments; i++) {
            double a0 = i * Math.PI * 2 / segments, a1 = (i + 1) * Math.PI * 2 / segments;
            V3 d0 = u.mul(Math.cos(a0)).add(v.mul(Math.sin(a0)));
            V3 d1 = u.mul(Math.cos(a1)).add(v.mul(Math.sin(a1)));
            V3 p0 = c.add(d0.mul(inner)), p1 = c.add(d0.mul(outer)), p2 = c.add(d1.mul(outer)), p3 = c.add(d1.mul(inner));
            quad(vc, m, p0, p1, p2, p3, r, g, b, alpha);
            quad(vc, m, p3, p2, p1, p0, r, g, b, alpha);
        }
    }

    static void quad(VertexConsumer vc, Matrix4f m, V3 a, V3 b, V3 c, V3 d, int r, int g, int bl, int al) {
        vc.vertex(m, (float) a.x(), (float) a.y(), (float) a.z()).color(r, g, bl, al);
        vc.vertex(m, (float) b.x(), (float) b.y(), (float) b.z()).color(r, g, bl, al);
        vc.vertex(m, (float) c.x(), (float) c.y(), (float) c.z()).color(r, g, bl, al);
        vc.vertex(m, (float) d.x(), (float) d.y(), (float) d.z()).color(r, g, bl, al);
    }

    // ------------------------------------------------------------- частицы

    private static final int[] window = new int[30];
    private static int windowPos;

    /** Сколько наших частиц живо примерно сейчас (за последние 1.5 с). */
    static int alive() {
        int sum = 0;
        for (int w : window) sum += w;
        return sum;
    }

    /**
     * Декоративные частицы: подъём в восходящих потоках и искры у колец
     * ускорения. Предел — по профилю (80 / 160 / 300), при FPS ниже 45 —
     * вдвое меньше, ниже 30 — вчетверо.
     */
    static void particles(MinecraftClient mc) {
        windowPos = (windowPos + 1) % window.length;
        window[windowPos] = 0;
        SkyWorld.ClientView view = SkyWorld.view;
        Track track = view.track();
        if (track == null || mc.world == null || mc.player == null || mc.isPaused()) return;
        int fps = mc.getCurrentFps();
        double factor = fps > 0 && fps < 30 ? 0.25 : fps > 0 && fps < 45 ? 0.5 : 1;
        int budget = (int) (SkyConfig.particleBudget() * factor);
        V3 me = new V3(mc.player.getX(), mc.player.getY(), mc.player.getZ());
        var random = mc.world.random;
        for (Zone z : track.zones) {
            V3 mid = z.min().lerp(z.max(), 0.5);
            if (mid.distance(me) > 90) continue;
            for (int i = 0; i < 3 && alive() < budget; i++) {
                double x = z.min().x() + random.nextDouble() * (z.max().x() - z.min().x());
                double zz = z.min().z() + random.nextDouble() * (z.max().z() - z.min().z());
                double y = z.min().y() + random.nextDouble() * (z.max().y() - z.min().y());
                mc.world.addParticle(ParticleTypes.CLOUD, x, y, zz, 0, 0.25 + random.nextDouble() * 0.2, 0);
                window[windowPos]++;
            }
        }
        int start = Math.min(view.nextRing(), track.ringCount());
        for (int i = start; i < Math.min(track.ringCount(), start + 3); i++) {
            Ring r = track.rings.get(i);
            if (!r.isBoost() || r.center().distance(me) > 60) continue;
            for (int k = 0; k < 2 && alive() < budget; k++) {
                double a = random.nextDouble() * Math.PI * 2;
                V3 u = r.normal().cross(V3.UP).normalize();
                if (u.lengthSq() == 0) u = new V3(1, 0, 0);
                V3 v = r.normal().cross(u).normalize();
                V3 p = r.center().add(u.mul(Math.cos(a) * r.radius())).add(v.mul(Math.sin(a) * r.radius()));
                mc.world.addParticle(ParticleTypes.ELECTRIC_SPARK, p.x(), p.y(), p.z(),
                        r.normal().x() * 0.2, r.normal().y() * 0.2, r.normal().z() * 0.2);
                window[windowPos]++;
            }
        }
    }
}
