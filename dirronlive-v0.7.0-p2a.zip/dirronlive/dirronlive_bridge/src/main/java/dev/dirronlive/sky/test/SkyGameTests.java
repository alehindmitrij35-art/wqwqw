package dev.dirronlive.sky.test;

import dev.dirronlive.bridge.BridgeProtocol;
import dev.dirronlive.bridge.MiniJson;
import dev.dirronlive.parkour.world.ParkourWorld;
import dev.dirronlive.sky.SkyWorld;
import dev.dirronlive.sky.core.Checkpoint;
import dev.dirronlive.sky.core.Ring;
import dev.dirronlive.sky.core.Sector;
import dev.dirronlive.sky.core.SkyRun;
import dev.dirronlive.sky.core.Track;
import dev.dirronlive.sky.core.V3;
import dev.dirronlive.sky.core.Zone;
import dev.dirronlive.sky.map.SkyIslands;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.test.GameTest;
import net.minecraft.test.TestContext;

/**
 * Проверки «Небесного разлома» в настоящем Minecraft (сервер без клиента):
 * старт и отсчёт, полёт через кольца, возврат на контрольную точку,
 * пауза, действия зрителей с ответами, «Временной разлом» и блоки карты.
 * Игрока двигаем сами (тиками), как будто он летит. В журнал пишется
 * строка SKY_CHECK ok|fail.
 */
public final class SkyGameTests implements FabricGameTest {
    static final double X = 30_000.5, Y = 200, Z = 30_000.5;

    /** Прямая трасса вдоль +Z: 2 сектора по 3 кольца каждые 20 блоков. */
    static Track line() {
        List<Sector> sectors = new ArrayList<>();
        int order = 0;
        for (int s = 0; s < 2; s++) {
            List<Ring> rings = new ArrayList<>();
            for (int i = 0; i < 3; i++) {
                boolean last = s == 1 && i == 2;
                Ring.Kind kind = last ? Ring.Kind.FINISH : (s == 0 && i == 1 ? Ring.Kind.BOOST : Ring.Kind.NORMAL);
                rings.add(new Ring(order, s, new V3(X, Y, Z + 20 + order * 20), new V3(0, 0, 1), 4, kind,
                        kind == Ring.Kind.BOOST ? 1.6 : 0));
                order++;
            }
            sectors.add(new Sector(s, "Тест " + (s + 1), Checkpoint.before(rings.get(0), 10, 0, 0.9), rings));
        }
        return new Track("gametest_line", "Проверка", 1, sectors,
                List.of(new Zone(Zone.Kind.LIFT, new V3(X - 3, Y - 5, Z + 200), new V3(X + 3, Y + 5, Z + 206), 0.1)),
                new Track.Spot(new V3(X, Y + 1, Z - 20), 0), null, null, null,
                new V3(X - 300, Y - 60, Z - 300), new V3(X + 300, Y + 100, Z + 400), Y - 50, 2.4, 60, Track.OnMiss.ERROR);
    }

    static SkyWorld sky(TestContext ctx) {
        SkyWorld sw = SkyWorld.get(ctx.getWorld().getServer());
        if (sw.track() == null || !"gametest_line".equals(sw.track().id)) sw.setTrack(line());
        return sw;
    }

    static void check(TestContext ctx, String name, boolean ok, String details) {
        System.out.println("SKY_CHECK " + (ok ? "ok" : "fail") + " | " + name + " | " + details);
        if (!ok) throw new AssertionError(name + ": " + details);
    }

    static ServerPlayerEntity pilot(TestContext ctx, SkyWorld sw) {
        ServerPlayerEntity player = ctx.createMockCreativeServerPlayerInWorld();
        SkyWorld.Result r = sw.command(player, "start");
        check(ctx, "старт", r.ok(), r.text());
        return player;
    }

    /** Двигать игрока по прямой (центр тела) каждый тик, пока идёт заезд. */
    static void glide(ServerPlayerEntity player, double x, double y, double z) {
        player.setPosition(x, y - 0.3, z);
        player.setOnGround(false);
    }

    // ---------------------------------------------------------------------

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "s01_blocks", tickLimit = 100)
    public void skyMapBlocksExist(TestContext ctx) {
        SkyIslands.Layout layout = SkyIslands.generate(0, 0, 0);
        TreeSet<String> used = new TreeSet<>(layout.blueprint().blocks().values());
        StringBuilder bad = new StringBuilder();
        for (String b : used) if (ParkourWorld.parseState(b) == null) bad.append(' ').append(b);
        check(ctx, "блоки «Небесных островов»", bad.length() == 0, used.size() + " видов блоков" + bad);
        check(ctx, "трасса без проблем", layout.track().problems().isEmpty(), layout.track().problems().toString());
        ctx.complete();
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "s02_flight", tickLimit = 400)
    public void countdownLaunchRingsFinish(TestContext ctx) {
        SkyWorld sw = sky(ctx);
        ServerPlayerEntity player = pilot(ctx, sw);
        check(ctx, "отсчёт: висим", sw.run(player).phase() == SkyRun.Phase.COUNTDOWN && player.getAbilities().flying,
                "фаза " + sw.run(player).phase());
        double[] z = {0};
        int[] t = {0};
        ctx.runAtEveryTick(() -> {
            t[0]++;
            SkyRun run = sw.run(player);
            if (t[0] == 62) {
                check(ctx, "старт полёта", run.phase() == SkyRun.Phase.RUNNING && !player.getAbilities().flying
                                && player.getAbilities().invulnerable
                                && player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA),
                        "фаза " + run.phase() + ", полёт " + player.getAbilities().flying);
                Checkpoint cp = run.checkpoint();
                check(ctx, "на контрольной точке", player.getPos().distanceTo(new net.minecraft.util.math.Vec3d(
                        cp.pos().x(), cp.pos().y() - 0.3, cp.pos().z())) < 1, "позиция " + player.getPos());
                z[0] = cp.pos().z();
            }
            if (t[0] > 62 && run.phase() == SkyRun.Phase.RUNNING) {
                z[0] += 1.5;
                glide(player, X, Y, z[0]);
            }
            if (run.phase() == SkyRun.Phase.FINISHED && t[0] < 1000) {
                t[0] = 1000;
                check(ctx, "финиш", run.nextRing() == 6 && run.errors() == 0, "колец " + run.nextRing() + ", ошибок " + run.errors());
                String json = sw.statusFor(player).toJson();
                Map<String, Object> st = MiniJson.parseObject(json);
                check(ctx, "состояние для программы", "finished".equals(st.get("phase")) && ((Number) st.get("passed")).intValue() == 6
                        && ((Number) st.get("bestMs")).longValue() > 0, json);
                sw.command(player, "stop");
                ctx.complete();
            }
        });
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "s03_return", tickLimit = 300)
    public void fallReturnsToSectorCheckpoint(TestContext ctx) {
        SkyWorld sw = sky(ctx);
        ServerPlayerEntity player = pilot(ctx, sw);
        int[] t = {0};
        double[] z = {0};
        ctx.runAtEveryTick(() -> {
            t[0]++;
            SkyRun run = sw.run(player);
            if (t[0] == 62) z[0] = run.checkpoint().pos().z();
            if (t[0] > 62 && t[0] < 140) {
                z[0] += 0.8;
                glide(player, X, Y, z[0]);
            }
            if (t[0] == 140) glide(player, X, Y - 70, z[0]); // ниже трассы
            if (t[0] == 142) {
                Checkpoint cp = run.checkpoint();
                boolean back = Math.abs(player.getZ() - cp.pos().z()) < 1 && Math.abs(player.getY() - (cp.pos().y() - 0.3)) < 1;
                check(ctx, "падение → контрольная точка", back && run.crashes() == 1 && run.protection() > 0,
                        "ошибок " + run.crashes() + ", z " + player.getZ() + " → " + cp.pos().z());
                sw.command(player, "stop");
                ctx.complete();
            }
        });
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "s04_pause", tickLimit = 300)
    public void pauseHoldsAndResumeCountsDown(TestContext ctx) {
        SkyWorld sw = sky(ctx);
        ServerPlayerEntity player = pilot(ctx, sw);
        int[] t = {0};
        long[] frozen = {0};
        ctx.runAtEveryTick(() -> {
            t[0]++;
            SkyRun run = sw.run(player);
            if (t[0] > 62 && t[0] < 80) glide(player, X, Y, run.checkpoint().pos().z() + (t[0] - 62));
            if (t[0] == 80) {
                check(ctx, "пауза", sw.command(player, "pause").ok() && player.getAbilities().flying, "");
                frozen[0] = run.ticks();
            }
            if (t[0] == 120) {
                check(ctx, "на паузе время стоит", run.ticks() == frozen[0] && run.phase() == SkyRun.Phase.PAUSED,
                        run.ticks() + " / " + frozen[0]);
                sw.command(player, "resume");
            }
            if (t[0] == 182) {
                check(ctx, "продолжение после отсчёта", run.phase() == SkyRun.Phase.RUNNING && !player.getAbilities().flying,
                        "фаза " + run.phase());
                sw.command(player, "stop");
                ctx.complete();
            }
        });
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "s05_actions", tickLimit = 300)
    public void viewerActionsAnswerWithReasons(TestContext ctx) {
        SkyWorld sw = sky(ctx);
        ServerPlayerEntity player = pilot(ctx, sw);
        List<String> acks = new ArrayList<>();
        int[] t = {0};
        ctx.runAtEveryTick(() -> {
            t[0]++;
            SkyRun run = sw.run(player);
            if (t[0] > 62) glide(player, X + 30, Y, run.checkpoint().pos().z() + (t[0] - 62) * 0.5);
            if (t[0] == 130) { // защита после старта закончилась
                send(sw, player, acks, "a1", "crosswind");
                send(sw, player, acks, "a1", "crosswind"); // повтор того же события
                send(sw, player, acks, "a2", "heavy_wings");
                send(sw, player, acks, "a3", "turbulence"); // третий эффект движения
                send(sw, player, acks, "a4", "guardian");
                check(ctx, "ответы на действия", acks.equals(List.of(
                                "a1 accepted", "a1 started", "a1 started", "a2 accepted", "a2 started",
                                "a3 accepted", "a3 deferred", "a4 accepted", "a4 started")),
                        acks.toString());
                var f = sw.forcesFor(player);
                check(ctx, "силы эффектов у игрока", f.push().length() > 0 && f.sink() > 0, String.valueOf(f));
                check(ctx, "щит ангела", run.shield(), "");
                var st = sw.statusFor(player);
                check(ctx, "эффекты в состоянии", st.effects().size() == 3 && st.queued() == 1, st.toJson());
            }
            if (t[0] == 240) {
                check(ctx, "отложенный стартовал сам", acks.contains("a3 started") && acks.contains("a1 finished"), acks.toString());
                sw.command(player, "stop");
                check(ctx, "остановка завершает всё", acks.contains("a3 finished") && acks.contains("a4 finished"), acks.toString());
                ctx.complete();
            }
        });
    }

    static void send(SkyWorld sw, ServerPlayerEntity player, List<String> acks, String id, String action) {
        BridgeProtocol.SkyAction a = BridgeProtocol.parseSkyAction(MiniJson.object("type", "skyAction", "id", id,
                "action", action, "viewer", "Mira", "repeat", "extend"));
        sw.action(player, a, json -> {
            Map<String, Object> m = MiniJson.parseObject(json);
            acks.add(m.get("id") + " " + m.get("state"));
        });
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "s06_rift", tickLimit = 300)
    public void timeRiftRewindsFlight(TestContext ctx) {
        SkyWorld sw = sky(ctx);
        ServerPlayerEntity player = pilot(ctx, sw);
        List<String> acks = new ArrayList<>();
        int[] t = {0};
        double[] z = {0};
        ctx.runAtEveryTick(() -> {
            t[0]++;
            SkyRun run = sw.run(player);
            if (t[0] == 62) z[0] = run.checkpoint().pos().z();
            if (t[0] > 62 && t[0] < 200) {
                z[0] += 0.5;
                glide(player, X - 30, Y, z[0]);
            }
            if (t[0] == 200) {
                double before = player.getZ();
                send(sw, player, acks, "r1", "time_rift");
                double after = player.getZ();
                check(ctx, "Временной разлом: назад", acks.contains("r1 started") && before - after > 20 && before - after < 40,
                        "z " + before + " → " + after + " " + acks);
                sw.command(player, "stop");
                ctx.complete();
            }
        });
    }

    @GameTest(templateName = EMPTY_STRUCTURE, batchId = "s07_idle", tickLimit = 100)
    public void actionsWithoutRunAreRejected(TestContext ctx) {
        SkyWorld sw = sky(ctx);
        ServerPlayerEntity player = ctx.createMockCreativeServerPlayerInWorld();
        List<String> acks = new ArrayList<>();
        send(sw, player, acks, "i1", "tailwind");
        check(ctx, "без заезда — отклонено", acks.equals(List.of("i1 accepted", "i1 rejected")) || acks.equals(List.of("i1 rejected")),
                acks.toString());
        ctx.complete();
    }
}
