package dev.dirronlive.sky.core;

/**
 * Кольцо трассы. {@code normal} — направление, в котором кольцо проходят
 * (единичный вектор), {@code radius} — внутренний радиус в блоках.
 * {@code order} — номер кольца по всей трассе (с 0), {@code sector} — с 0.
 */
public record Ring(int order, int sector, V3 center, V3 normal, double radius, Kind kind, double boost) {
    public enum Kind { NORMAL, BOOST, FINISH }

    public Ring {
        normal = normal.normalize();
        if (radius <= 0) throw new IllegalArgumentException("радиус кольца должен быть больше 0");
    }

    public boolean isBoost() {
        return kind == Kind.BOOST && boost > 0;
    }
}
