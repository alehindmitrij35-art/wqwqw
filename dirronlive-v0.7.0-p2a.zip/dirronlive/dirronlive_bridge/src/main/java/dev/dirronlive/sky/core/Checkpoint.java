package dev.dirronlive.sky.core;

/**
 * Контрольная точка сектора: откуда игрок продолжает полёт после ошибки.
 * Точка в воздухе перед первым кольцом сектора, направление — на это
 * кольцо, {@code speed} — безопасная скорость (блоков за тик).
 */
public record Checkpoint(V3 pos, float yaw, float pitch, double speed) {
    public V3 direction() {
        return V3.look(yaw, pitch);
    }

    public V3 velocity() {
        return direction().mul(speed);
    }

    /** Точка в {@code back} блоках перед кольцом, смотрит прямо в его центр. */
    public static Checkpoint before(Ring ring, double back, double rise, double speed) {
        V3 pos = ring.center().sub(ring.normal().mul(back)).add(0, rise, 0);
        float[] a = V3.angles(ring.center().sub(pos));
        return new Checkpoint(pos, a[0], a[1], speed);
    }
}
